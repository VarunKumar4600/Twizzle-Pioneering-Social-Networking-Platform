export const mutations = `#graphql
    createTweet(payload:CreateTweetData!):Tweet
`;
